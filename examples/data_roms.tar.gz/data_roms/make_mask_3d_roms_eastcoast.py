#!/usr/bin/env python

import netCDF4 as nc
import numpy as npy

def write_3d_roms_mask(ncfile,lon_array,lat_array,z_profile,time,var,varname):
        fid = nc.Dataset(ncfile, 'w', format='NETCDF3_CLASSIC')
        fid.description = '3D mask for ROMS east coast'
        # dimensions
        fid.createDimension('z', var.shape[0])
        fid.createDimension('y', var.shape[1])
        fid.createDimension('x', var.shape[2])
        # variables
        latitudes  = fid.createVariable('nav_lat', 'f4', ('y','x',))
        longitudes = fid.createVariable('nav_lon', 'f4', ('y','x',))
        zprof      = fid.createVariable('z', 'f4', ('z',))
        variable   = fid.createVariable(varname, 'f8', ('z','y','x',))
        # data
        latitudes[:,:]    = lat_array
        longitudes[:,:]   = lon_array
        zprof[:]          = z_profile
        variable[:,:,:] = var
        # close
        fid.close()
        return None

#------------------- Read grid from ROMS file -----------#

roms_filein = './roms_eastcoast.nc'

fid = nc.Dataset(roms_filein,'r')
bathy_in = fid.variables['h'][:]
mask_in = fid.variables['mask_rho'][:]
lon = fid.variables['lon_rho'][:]
lat = fid.variables['lat_rho'][:]
fid.close()

#-------------- pick levels of interest ----------------#

levels = [0,10,20,50,75,100,250,500,750,1000,1500,2000,2500]

sy,sx = bathy_in.shape
sz = len(levels)

bathy_out = npy.zeros((sz,sy,sx))

for kk in npy.arange(sz):
        tmp = 0. * bathy_in.copy()
        tmp[npy.where(bathy_in > levels[kk])] = 1
        bathy_out[kk,:,:] = tmp[:,:] * mask_in[:,:]


mask_3d_out = './mask_ROMS_eastcoast.nc'

write_3d_roms_mask(mask_3d_out,lon,lat,levels,0.,bathy_out,'mask')

